#!/bin/bash

# Starting loop
# Modified code from Lecture 6 "while" Loop: menu.sh
clear;loop=y
while [ "$loop" == "y" ];
do

# Menu Functions 
grub_processing(){
echo "Processing grub.txt"
if [ ! -f grub.txt ]
then
echo "grub.txt does not exist"
return
fi
echo "Occurances of word Linux:"
grep -o "Linux" grub.txt | wc -l
echo "Lines containing word Linux"
grep "Linux" grub.txt
echo "Number of empty lines"
grep -c "^$" grub.txt
echo "Extracting and listing lines beggining with #"
grep "^#" grub.txt > extracted.txt
cat extracted.txt
}

ufw_processing(){
echo "Processing ufw.txt"
if [ ! -f ufw.txt ]
then
echo "ufw.txt does not exist"
return
fi

echo "Lines containing 6 letter words starting with a and ending with t:"
grep -E '\ba....t\b' ufw.txt

echo "Lines starting with D:"
grep -c "^D" ufw.txt

mapfile -t lines < ufw.txt

echo "Array length"
echo ${#lines[@]}

echo "Every third line:"
for ((i=2; $i<${#lines[@]}; i=$i+3))
do
echo "${lines[$i]}"
done
}

write_menu(){
echo "Write menu"
echo "Enter file name:"
read file
touch "$file"
echo "Type finish to stop writing"
while true
do read line
if [ "$line" = "finish" ]
then
break
fi
echo "$line" >> "$file"
done
echo "Contents of the $file:"
cat "$file"
}


# Menu loop 
# Modified code from Lecture 6 "while" Loop: menu.sh
echo "Welcome"
echo "-------"
echo "Please make a selection"
echo "1. Processing grub.txt"
echo "2. Processing ufw.txt"
echo "3. Write Menu"
echo "4. Exit"
echo "Enter a number 1 to 4"
echo -n 
read choice
case $choice in
1) grub_processing;;
2) ufw_processing;;
3) write_menu;;
4) echo "Thank you and goodbye!"
loop=n;;
*) echo "Illegal Choice";;
esac
echo
done

