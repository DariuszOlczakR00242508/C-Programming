#1/bin/bash

count=1
renamed_files=()

# Provide a folder path in parameter for a script
echo "You enterd:"			
echo "$1" # Lecture 3 Shell Parameters
cd "$1"
echo "13 .avif files will be renamed and backup folder created in home directory"
echo "Printing list of contents:"
ls -l
for file in *.avif
do
if [ $count -gt 13 ] # Lecture 5 Modified code Logical.sh/Number Comparison Operators
then 
break
fi

# Base name for images: "sun-foto-xx.avif"
number=$(printf "%02d" $count)  
new_name="sun-foto-$number.avif"
mv "$file" "$new_name"

# Use an array structure to store the names of all renamed files
renamed_files=("${renamed_files[@]}" "$new_name") # Lecture6 mofified array5.sh
count=$((count+1)) # Modified for4.sh
done

# After renaming script should output following: name, group, month of creation, time of creation
echo "renamed_files array content:"
for file in "${renamed_files[@]}" # Lecture 6 Loading Content into Array Modified array9.sh
do
ls -l "$file" | awk '{print "Name:", $9, " Group:", $4, " Month:", $6, " Time:", $8}' # Lecture 8 Piping Command
done

# Until loop shoiuld be used to iterate throuch array and print out all the file names
i=0
until [ $i -ge ${#renamed_files[@]} ]
do
echo "${renamed_files[$i]}"
i=$((i+1))
done

# Move the renamed files into a new folder and use tar tool to create a compressed archive
mkdir renamed
mv sun-foto-*.avif renamed # Lecture 2 Filename expansions

# Save in the folder called backup in your home directory
mkdir ~/backup # Lecture 3 Additional Shell features
tar -czf ~/backup/renamed_backup.tar.gz renamed # Lecture 3 File compression and Restoring

# Output the content of the backup folder in your home directory to the terminall  
echo "Content of the backup folder in your home directory:"
ls $HOME

## SOLUTION DOES NOT MEET ALL REQUIREMENTS. NO ARGUMENT CHECK DONE. OUTPUTTING IS NOT CONSISTENT WITH REQUIREMENTS.
## NO SOLUTION CONCEPT DESCRIPTION.

## SCORE = 23 MARKS
