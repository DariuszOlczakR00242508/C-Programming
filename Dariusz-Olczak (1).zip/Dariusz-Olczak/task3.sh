#!/bin/bash

# Create user function 
create_user() {
user=$1  # Lecture 3 Shell Parameters

# Check if user exists
if id "$user" >/dev/null 2>&1
then
    echo "User $user already exists - skipping"
else
    useradd -m "$user"
    echo "User $user created"

    created_users+=("$user")
fi
}

delete_user() {
user=$1 # Lecture 3 Shell Parameters

userdel -r "$user"
echo "User $user deleted"
}



# Script must be run as root
if [ "$EUID" -ne 0 ]  # Lecture 5 Modified code Logical.sh/Number Comparison Operators
then
    echo "Please run this script as root"
    exit 1
fi

# Check presence of input argument in parameter
if [ $# -eq 0 ]  # Lecture 5 Modified code Logical.sh/Number Comparison Operators
then
    echo "Usage: $0 userlist.txt"
    exit 1
fi

input_file=$1

# Check if file exists and is not empty
if [ ! -f "$input_file" ] || [ ! -s "$input_file" ] # Lecture 5 Logical Operators
then
    echo "Input file missing or empty"
    exit 1
fi

# Create array to store created users
created_users=() # Lecture 6 Array operations


while read username
do
    create_user "$username"
done < "$input_file"

echo "---- /etc/passwd ----"
cat /etc/passwd

echo "---- /home directory ----"
ls /home


# Menu loop 
# Modified code from Lecture 6 "while" Loop: menu.sh
echo "Do you want to delete the created accounts? (yes/no)"
read answer

case $answer in
yes)

    for user in "${created_users[@]}"
    do
        delete_user "$user"
    done

    echo "---- /etc/passwd after deletion ----"
    cat /etc/passwd

    echo "---- /home directory after deletion ----"
    ls /home
    ;;

no)
    echo "Accounts remain on system"
    ;;

*)
    echo "Invalid option"
    ;;
esac


## THE ARGUMENT CHECK IS NOT PRECISE. CODE QUALITY COULD BE IMPROVED.
## SOME WEAK INTERVIEW PERFORMANCE.

## SCORE = 25 MARKS

## TOTAL SCORE = 67 MARKS
