#!/bin/bash

# This script is to delete project folder
# Removing created proj_folder that contains mixed files
rm -rf proj_folder # Lecture 2 Using script to run a task
rm -rf renamed
ls


# Removing created backup file in home directory 
cd $HOME # Lecture 3  Environmental Variables
rm -rf backup
ls
