#!/bin/bash

# This is a script to to create directory proj_folder and mix of 20 different files

mkdir proj_folder			# Create directory
cd proj_folder				# Change dir to created folder
for ((i=1;$i<=15;i=$i+1))		# Loop 15 times to create 15 x 3 types of files
do
touch "image_$i.avif" "picture_$i.png" "shot_$i.jpg"
done
echo "Folder created"
cd ..
ls
cd proj_folder
ls
cd ..
